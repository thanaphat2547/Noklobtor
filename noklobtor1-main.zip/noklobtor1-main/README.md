# Noklobtor or "นกหลบท่อ" is a FlappyBird Parody project for educational purpose in CS4773 - Computer Graphics (Academy Year 1/2023).
